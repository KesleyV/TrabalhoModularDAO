package Users;


import java.util.List;

public interface DAO<tipoItem, tipoChave> {

	public tipoItem get(tipoChave chave);

	public void adicionar(tipoItem item);

	public void atualizar(tipoItem item);

	public void deletar(tipoChave chave);

	public List<tipoItem> getAll();

}
