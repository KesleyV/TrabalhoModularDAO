package Testes;

import static org.junit.Assert.assertEquals;
import java.util.List;
import org.junit.Test;
import Aplicativo.VagaDAO;
import Users.Vaga;

public class VagaTeste {

	@Test
	public void adicionarTeste() {
		VagaDAO arquivoAtendimento = new VagaDAO();
		List<Vaga> lista = arquivoAtendimento.getAll();
		int tamanho = lista.size();
		arquivoAtendimento.adicionar(new Vaga(115, "14/05/2020", 116, "nome", "assunto"));
		lista = arquivoAtendimento.getAll();
		assertEquals("Erro ao inserir", (tamanho + 1), lista.size());
	}

	@Test
	public void getTeste() {
		VagaDAO arquivoVaga = new VagaDAO();
		arquivoVaga.adicionar(new Vaga(115, "14/05/2020", 117, "nome", "assunto"));
		Vaga vaga = arquivoVaga.get(1);
		assertEquals("Erro ao buscar", 1, vaga.getId());
	}

	@Test
	public void atualizarTeste() {
		VagaDAO arquivoMonitor = new VagaDAO();
		arquivoMonitor.adicionar(new Vaga(115, "14/05/2020", 118, "nome", "assunto"));
		Vaga vaga = arquivoMonitor.get(1);
		vaga.setData("20/05/2019");
		arquivoMonitor.atualizar(vaga);
		Vaga novo = arquivoMonitor.get(1);
		assertEquals("Erro ao editar", "20/05/2019", novo.getData());
	}

	@Test
	public void deletarTeste() {
		VagaDAO arquivoVaga = new VagaDAO();
		arquivoVaga.adicionar(new Vaga(115, "14/05/2020", 119, "nome", "assunto"));
		arquivoVaga.adicionar(new Vaga(115, "17/05/2020", 120, "nome", "assunto"));
		List<Vaga> lista = arquivoVaga.getAll();
		int tamanho = lista.size();
		arquivoVaga.deletar(2);
		lista = arquivoVaga.getAll();
		assertEquals("Erro ao apagar", (tamanho - 1), lista.size());
	}
}
