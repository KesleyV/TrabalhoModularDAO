package Testes;

import static org.junit.Assert.assertEquals;
import java.util.List;
import org.junit.Test;
import Aplicativo.MonitorDAO;
import Users.Monitor;

public class MonitorTeste {
	
	private static MonitorDAO arquivoMonitor = new MonitorDAO();

	@Test
	public void adicionarTeste() {
		List<Monitor> lista = arquivoMonitor.getAll();
		int tamanho = lista.size();
		arquivoMonitor.adicionar(new Monitor("nome", 989, "curso", "disciplina"));
		lista = arquivoMonitor.getAll();
		assertEquals("Erro ao inserir", (tamanho + 1), lista.size());
	}

	@Test
	public void getTeste() {
		arquivoMonitor.adicionar(new Monitor("nome", 342, "curso", "disciplina"));
		Monitor monitor = arquivoMonitor.get(342);
		assertEquals("Erro ao buscar", 342, monitor.getId());
	}

	@Test
	public void atualizarTeste() {
		arquivoMonitor.adicionar(new Monitor("nome", 654, "curso", "disciplina"));
		Monitor monitor = arquivoMonitor.get(654);
		monitor.setNome("novo nome");
		arquivoMonitor.atualizar(monitor);
		Monitor novo = arquivoMonitor.get(654);
		assertEquals("Erro ao editar", "novo nome", novo.getNome());
	}

	@Test
	public void deletarTeste() {
		arquivoMonitor.adicionar(new Monitor("nome", 777, "curso", "disciplina"));
		arquivoMonitor.adicionar(new Monitor("nome", 867, "curso", "disciplina"));
		List<Monitor> lista = arquivoMonitor.getAll();
		int tamanho = lista.size();
		arquivoMonitor.deletar(777);
		lista = arquivoMonitor.getAll();
		assertEquals("Erro ao apagar", (tamanho - 1), lista.size());
	}
}
