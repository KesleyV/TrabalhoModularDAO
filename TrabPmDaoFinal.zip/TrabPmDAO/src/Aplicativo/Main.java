package Aplicativo;

import java.util.List;


import Users.Vaga;
import Users.Monitor;

public class Main {

	private static Monitor monitor = null;
	private static String coordenador = null;
	private static MonitorDAO monitorDAO = new MonitorDAO();
	private static VagaDAO vagaDAO = new VagaDAO();

	public static void main(String[] args) {
		int opcao;

		do {
			System.out.println("Sistema de Monitoria \n"
					+ "0 - Encerrar\n\nVoc� deseja acessar como: \n\n1 - Monitor \n2 - Coordenador");
			System.out.print("-------------------------------------\nOp��o: ");
			opcao = readInt();

			switch (opcao) {
			case 1:
				clear();
				Monitoria();
				clear();
				break;
			case 2:
				clear();
				Coordena��o();
				clear();
				break;
			case 0:
				clear();
				System.out.println("\nPrograma Encerrado...");
				break;
			default:
				clear();
				System.out.println("\nOp��o Inv�lida!");
				pause();
			}

		} while (opcao != 0);

	}

	private static void Monitoria() {
		int opcao;

		do {
			System.out.print("N�mero de matr�cula: ");
			int matricula = readInt();
			monitor = monitorDAO.get(matricula);
			clear();
		} while (monitor == null);

		System.out.println("Logado como: " + monitor.getNome());
		pause();

		do {
			System.out.println(
					"[MONITOR] Sistema de Monitoria \n"
							+ "0 - Voltar\n\nAtendimentos: \n\n1 - Registrar \n2 - Alterar \n3 - Excluir \n4 - Buscar \n5 - Listar");
			System.out.print("-----------------------------------------------\nOp��o: ");
			opcao = readInt();

			switch (opcao) {
			case 1:
				clear();
				registrarVaga();
				clear();
				break;
			case 2:
				clear();
				editarVaga();
				clear();
				break;
			case 3:
				clear();
				excluirVagas();
				clear();
				break;
			case 4:
				clear();
				pesquisarVaga();
				clear();
				break;
			case 5:
				clear();
				listarVagas();
				clear();
				break;
			case 0:
				break;
			default:
				clear();
				System.out.println("\nOp��o Inv�lida!");
				pause();
			}

		} while (opcao != 0);

	}

	private static void Coordena��o() {
		int opcao;

		do {
			System.out.print("Curso: ");
			coordenador = readLine().toUpperCase();
			clear();
		} while (coordenador == null);

		do {
			System.out.println(
					"[COORDENADOR] Sistema de Monitoria \n"
							+ "0 - Voltar\n\nMonitores: \n\n1 - Cadastrar \n2 - Alterar \n3 - Excluir \n4 - Buscar \n5 - Listar");
			System.out.print("---------------------------------------------------\nOp��o: ");
			opcao = readInt();

			switch (opcao) {
			case 1:
				clear();
				cadastrarMonitor();
				clear();
				break;
			case 2:
				clear();
				alterarMonitor();
				clear();
				break;
			case 3:
				clear();
				excluirMonitor();
				clear();
				break;
			case 4:
				clear();
				pesquisarMonitor();
				clear();
				break;
			case 5:
				clear();
				listarMonitores();
				clear();
				break;
			case 0:
				break;
			default:
				clear();
				System.out.println("\nOp��o Inv�lida!");
				pause();
			}

		} while (opcao != 0);

	}

	private static void listarMonitores() {
		System.out.println("\nLISTA DE MONITORES\n------------------\n");
		List<Monitor> lista = monitorDAO.getAll();

		for (Monitor m : lista) {
			if (m.getCurso().equals(coordenador))
				System.out.println(m + "\n");
		}
		pause();
	}

	private static void excluirMonitor() {
		System.out.println("\nEXCLUS�O DE MONITOR\n-------------------\n");

		int id;
		System.out.print("N�mero de matr�cula do Monitor: ");
		id = readInt();

		Monitor obj = monitorDAO.get(id);
		if ((obj != null && obj.getCurso().equals(coordenador))) {
			System.out.println("\n" + obj);

			monitorDAO.deletar(id);
			System.out.println("\nMonitor exclu�do com sucesso!");

		} else
			System.out.println("\nMonitor n�o encontrado!");
		pause();
	}

	private static void alterarMonitor() {
		System.out.println("\nALTERA��O DE MONITOR\n-------------------\n");

		int id;
		System.out.print("N�mero de matr�cula do Monitor: ");
		id = readInt();

		Monitor obj = monitorDAO.get(id);
		if ((obj != null && obj.getCurso().equals(coordenador))) {
			System.out.println("\n" + obj);
			System.out.println("\nPreencha com os novos dados:\n");
			System.out.print("Nome: ");
			obj.setNome(readLine());
			System.out.print("Disciplina: ");
			obj.setDisciplina(readLine());
			monitorDAO.atualizar(obj);

			System.out.println("\nCadastro alterado com sucesso!");

		} else
			System.out.println("\nMonitor n�o encontrado!");
		pause();
	}

	private static void cadastrarMonitor() {
		System.out.println("\nCADASTRO DE MONITOR\n-------------------\n");
		System.out.print("Nome: ");
		String nome = readLine();
		System.out.print("Matr�cula: ");
		int matricula = readInt();
		System.out.print("Disciplina: ");
		String disciplina = readLine();

		Monitor monitor = new Monitor(nome, matricula, coordenador, disciplina);
		monitorDAO.adicionar(monitor);

		System.out.println("\nCadastro realizado com sucesso!");
		pause();
	}

	private static void listarVagas() {
		System.out.println("\nLISTA DE VAGAS\n---------------------\n");
		List<Vaga> lista = vagaDAO.getAll();

		for (Vaga a : lista) {
			if (a.getMonitorID() == monitor.getId())
				System.out.println(a + "\n");
		}
		pause();
	}

	private static void excluirVagas() {
		System.out.println("\nEXCLUS�O DE REGISTRO DE VAGAS\n-----------------------------------\n");

		int id;
		System.out.print("ID do registro: ");
		id = readInt();

		Vaga obj = vagaDAO.get(id);
		if ((obj != null && obj.getMonitorID() == monitor.getId())) {
			System.out.println("\n" + obj);

			vagaDAO.deletar(id);
			System.out.println("\nRegistro exclu�do com sucesso!");

		} else
			System.out.println("\nRegistro n�o encontrado!");
		pause();
	}

	private static void editarVaga() {
		System.out.println("\nALTERA��O DE REGISTRO DE VAGAS\n------------------------------------\n");

		int id;
		System.out.print("ID do registro: ");
		id = readInt();

		Vaga obj = vagaDAO.get(id);
		if ((obj != null && obj.getMonitorID() == monitor.getId())) {
			System.out.println("\n" + obj);
			System.out.println("\nPreencha com os novos dados:\n");
			System.out.print("Data: ");
			obj.setData(readLine());
			System.out.print("Matr�cula do aluno: ");
			obj.setAlunoID(readInt());
			System.out.print("Nome do aluno: ");
			obj.setNomeAluno(readLine());
			System.out.print("Assunto: ");
			obj.setAssunto(readLine());
			vagaDAO.atualizar(obj);

			System.out.println("\nRegistro alterado com sucesso!");

		} else
			System.out.println("\nRegistro n�o encontrado!");
		pause();
	}

	private static void registrarVaga() {
		System.out.println("\nREGISTRO DE VAGA\n----------------------\n");
		System.out.print("Data: ");
		String data = readLine();
		System.out.print("Matr�cula do aluno: ");
		int matricula = readInt();
		System.out.print("Nome do aluno: ");
		String nome = readLine();
		System.out.print("Assunto: ");
		String assunto = readLine();

		Vaga vaga = new Vaga(monitor.getMatricula(), data, matricula, nome, assunto);
		vagaDAO.adicionar(vaga);

		System.out.println("\nRegistro realizado com sucesso!");
		pause();
	}

	private static void pesquisarMonitor() {
		System.out.println("\nPESQUISA DE MONITOR\n-------------------\n");

		int id;
		System.out.print("N�mero de matr�cula do Monitor: ");
		id = readInt();

		Monitor obj = monitorDAO.get(id);
		if ((obj != null && obj.getCurso().equals(coordenador)))
			System.out.println("\n" + obj);

		else
			System.out.println("\nMonitor n�o encontrado!");
		pause();
	}

	private static void pesquisarVaga() {
		System.out.println("\nPESQUISA DE REGISTRO DE VAGA\n-----------------------------------\n");

		int id;
		System.out.print("ID do registro: ");
		id = readInt();

		Vaga obj = vagaDAO.get(id);
		if ((obj != null && obj.getMonitorID() == monitor.getId()))
			System.out.println("\n" + obj);

		else
			System.out.println("\nRegistro n�o encontrado!");
		pause();
	}

	public static void pause() {
		System.out.println("\nPressione ENTER para continuar...");
		readLine();
		for (int i = 0; i < 50; i++)
			System.out.println();
	}

	public static void clear() {
		for (int i = 0; i < 50; i++)
			System.out.println();
	}
public static String readLine() {
		
		int ch;
		String r= "";
		boolean done= false;
		while (!done) {
			try {
				ch = System.in.read();
				if (ch < 0 || (char)ch == '\n')
					done = true;
				else if ((char)ch != '\r')
					r = r + (char) ch;
			}
			catch(java.io.IOException e){
				done = true;
			}
		}
		return r;
	}
	
	public static int readInt() {
		
		while(true) {
			try {
				return Integer.valueOf(readLine().trim()).intValue();
			}
			catch(NumberFormatException e){
				System.out.println("Erro ao converter para inteiro. Tente novamente!");
			}
		}
	}
	
	public static float readFloat() {
		
		while(true) {
			try {
				return Float.valueOf(readLine().trim()).floatValue();
			}
			catch(NumberFormatException e){
				System.out.println("Erro ao converter para float. Tente novamente!");
			}
		}
	}
}
