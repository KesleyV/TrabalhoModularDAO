package Aplicativo;

import java.util.List;

import Users.Monitor;
import Users.DAO;

public class MonitorDAO implements DAO<Monitor, Integer> {

	private static ArquivoMonitor<Monitor> arquivoMonitores;

	@Override
	public Monitor get(Integer chave) {
		Monitor monitor = null;

		try {
			arquivoMonitores = new ArquivoMonitor<>(Monitor.class.getConstructor(), "Monitores");

			monitor = (Monitor) arquivoMonitores.buscar(chave);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return monitor;
	}

	@Override
	public void adicionar(Monitor item) {
		try {
			arquivoMonitores = new ArquivoMonitor<>(Monitor.class.getConstructor(), "Monitores");

			arquivoMonitores.incluir(item);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void atualizar(Monitor item) {
		try {
			arquivoMonitores = new ArquivoMonitor<>(Monitor.class.getConstructor(), "Monitores");

			arquivoMonitores.alterar(item);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deletar(Integer chave) {
		try {
			arquivoMonitores = new ArquivoMonitor<>(Monitor.class.getConstructor(), "Monitores");

			arquivoMonitores.excluir(chave);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Monitor> getAll() {
		List<Monitor> monitores = null;

		try {
			arquivoMonitores = new ArquivoMonitor<>(Monitor.class.getConstructor(), "Monitores");

			monitores = arquivoMonitores.listar();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return monitores;
	}
}
