package Aplicativo;

import java.util.List;

import Users.Vaga;
import Users.DAO;

public class VagaDAO implements DAO<Vaga, Integer> {

	private static ArquivoVaga<Vaga> arquivoVaga;

	@Override
	public Vaga get(Integer chave) {
		Vaga vaga = null;

		try {
			arquivoVaga = new ArquivoVaga<>(Vaga.class.getConstructor(), "Vagas");

			vaga = (Vaga) arquivoVaga.buscar(chave);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return vaga;
	}

	@Override
	public void adicionar(Vaga item) {
		try {
			arquivoVaga = new ArquivoVaga<>(Vaga.class.getConstructor(), "Vagas");

			arquivoVaga.incluir(item);

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	@Override
	public void atualizar(Vaga item) {
		try {
			arquivoVaga = new ArquivoVaga<>(Vaga.class.getConstructor(), "Vagas");

			arquivoVaga.alterar(item);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deletar(Integer chave) {
		try {
			arquivoVaga = new ArquivoVaga<>(Vaga.class.getConstructor(), "Vagas");

			arquivoVaga.excluir(chave);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Vaga> getAll() {
		List<Vaga> vagas = null;

		try {
			arquivoVaga = new ArquivoVaga<>(Vaga.class.getConstructor(), "Vagas");

			vagas = arquivoVaga.listar();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return vagas;

	}
}
